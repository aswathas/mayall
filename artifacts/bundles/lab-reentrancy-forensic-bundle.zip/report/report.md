# reentrancy — Forensic Report

**Case reference:** lab-reentrancy  
**Generated:** 2026-10-30T22:10:40.877Z  
**Chain:** Ethereum  
**Severity:** CRITICAL  
**Confidence:** 97%  
**Evidence items:** 10

## Executive summary

The reproduction confirms a classic re-entrancy drain against `ReentrancyVault`, and the trace leaves no room for a benign reading of the sequence.

The flaw is an ordering violation in `withdraw()`. The function reads the caller's recorded balance, transfers that ETH to the caller, and only afterwards writes `balances[msg.sender] = 0`. Because the state write happens after the external call, the caller's `receive()` hook runs while the vault still believes the balance is outstanding. The attacker's contract uses that window to re-enter `withdraw()` six times inside a single transaction. The trace shows `ReentrancyVault::withdraw()` invoked seven times — the initial call plus six re-entries — each one nesting deeper than the last, with `ReentrancyAttacker::receive()` sitting between every pair. That nesting pattern is the signature of the exploit; the detector raises it as Reentrancy at 97% confidence.

The money movement is unambiguous. The vault's balance fell from 10 ETH to 4 ETH across the transaction, a deficit of 6 ETH, and the attacker's contract balance rose by exactly the same 6 ETH over its 1 ETH seed deposit. Of that 6 ETH, 1 ETH is the attacker's own capital making a round trip; the net value extracted from the pool's other depositors is 5 ETH. The storage diff shows the accounting consequence: `totalWithdrawn` moves from 0 to 6 ETH while `totalDeposited` sits at 11 ETH, so the vault's books claim 11 ETH against a physical balance of 4 ETH. The contract is left insolvent by 7 ETH and the depositor who trusted it cannot be made whole.

What makes this more than a textbook example is that it needs no flash loan, no oracle, no privileged key and no multi-transaction sequencing. A single funded contract, one call, and the bug does the rest. The fix is the checks-effects-interactions ordering — decrement the balance before the transfer — or a reentrancy mutex on the withdrawal path. Until then, any balance in the vault is available to whoever can be paid twice.


## 1. Scope

Case reference: lab-reentrancy
Scenario executed: reentrancy
Attack vector under investigation: Reentrancy
Chain: Ethereum
Target contract: ReentrancyVault (0x5615dEB798BB3E4dFa0139dFa1b3D433Cc23b72f)
Execution: C:\Users\aswat\Projects\w3-forensics\.tools\foundry\forge.exe test --match-path test/ReentrancyExploit.t.sol --match-test testExploit -vvvv
Executed at: 2026-10-30T22:10:32.784Z (2626 ms)

## 2. Attack sequence

Step 1 — Attacker deposits seed capital
The attacker contract deposits 1 ETH into the vault to open a withdrawable balance.
  gas: 60000 | value: 1000000000000000000 wei | tx: 0x0

Step 2 — Re-entrant withdraw loop
The attacker calls withdraw(). The vault sends ETH before decrementing balances, so receive() re-enters withdraw() repeatedly inside the same transaction.
  gas: 420000 | value: 0 wei | tx: 0x0

Step 3 — Victim funds drained
Each re-entrant call passes the same balance check because the state update happens only after the external call returns. The vault pays out the same balance repeatedly.
  gas: 900000 | value: 0 wei | tx: 0x0

## 3. State mutations (storage diff)

ReentrancyVault balances[attacker] (0xc6bd81b73d1fd76b6ab7b2a3e675f602f162633118b2ec0b74d6456669dd8579) [balance]
  before: 0x0000000000000000000000000000000000000000000000000000000000000000
  after:  0x0000000000000000000000000000000000000000000000000000000000000000

ReentrancyVault totalDeposited (0x0000000000000000000000000000000000000000000000000000000000000001) [state]
  before: 0x0000000000000000000000000000000000000000000000008ac7230489e80000
  after:  0x00000000000000000000000000000000000000000000000098a7d9b8314c0000

ReentrancyVault totalWithdrawn (0x0000000000000000000000000000000000000000000000000000000000000002) [state]
  before: 0x0000000000000000000000000000000000000000000000000000000000000000
  after:  0x0000000000000000000000000000000000000000000000006124fee993bc0000

## 4. Balance movements

ReentrancyVault 0x0000000000000000000000005615deb798bb3e4dfa0139dfa1b3d433cc23b72f
  before: 10000000000000000000 wei
  after:  4000000000000000000 wei
  delta:  -6000000000000000000 wei

ReentrancyAttacker 0x0000000000000000000000002e234dae75c793f67a35089c9d99245e1c58470b
  before: 1000000000000000000 wei
  after:  7000000000000000000 wei
  delta:  6000000000000000000 wei

Victim EOA 0x0000000000000000000000007fa9385be102ac3eac297483dd6233d62b3e1496
  before: 990000000000000000000 wei
  after:  990000000000000000000 wei
  delta:  0 wei

## 5. Pattern findings

1. Reentrancy — confidence 97%, severity critical
   The same contract entry point is re-entered before its state update completes, letting the attacker pull funds across nested calls.
   Evidence:
     - Trace shows ReentrancyVault::deposit invoked 2 times within a single transaction
     - Trace shows ReentrancyVault::withdraw invoked 7 times within a single transaction
     - Trace shows ReentrancyAttacker::receive invoked 7 times within a single transaction
     - Root cause narrative references reentran, re-entran, reentrancy
     - 9 value-bearing calls observed in the exploit transaction

## 6. Root cause and remediation

withdraw() transfers ETH to msg.sender before zeroing balances[msg.sender], so a malicious receiver can re-enter withdraw() and drain the vault in one transaction.

Recommended remediation: Review the affected contract paths and add invariant tests.

## 7. Evidence index

Artifact: artifacts/reentrancy.json
Trace: stored with the case, 177 lines
Gas flame nodes: 83
Pattern detections: 1
Reporter: Mayall forensic engine (Foundry simulation)

---

_Generated by Mayall — Web3 Exploit Forensics._