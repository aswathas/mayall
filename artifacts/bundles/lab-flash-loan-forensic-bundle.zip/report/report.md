# flash-loan — Forensic Report

**Case reference:** lab-flash-loan  
**Generated:** 2026-10-30T20:30:04.321Z  
**Chain:** Ethereum  
**Severity:** CRITICAL  
**Confidence:** 90%  
**Evidence items:** 15

## Executive summary

A local Foundry reproduction of a flash loan attack drained 250 ETH from the target contract in a single transaction.

Root cause: SpotOracle derives its price from a bond that the depositor can unwind instantly, so a flash loan buys a 9x price move inside one transaction. CollateralVault lends against that spot price, leaving 450 ETH of debt backed by 100 ETH of collateral.

The trace was classified as Oracle Manipulation with 90% confidence based on 3 piece(s) of evidence.

Secondary signals: Flash Loan, Reentrancy.

This summary was produced from the simulated execution evidence; the same slot can be filled with a MiniMax Code authored narrative.

## 1. Scope

Case reference: lab-flash-loan
Scenario executed: flash-loan
Attack vector under investigation: Flash Loan
Chain: Ethereum
Target contract: CollateralVault (0xF62849F9A0B5Bf2913b396098F7c7019b51A820a)
Execution: C:\Users\aswat\Projects\w3-forensics\.tools\foundry\forge.exe test --match-path test/FlashLoanExploit.t.sol --match-test testExploit -vvvv
Executed at: 2026-10-30T20:30:03.644Z (215 ms)

## 2. Attack sequence

Step 1 — Flash loan of 900 ETH
The attacker borrows 900 ETH from FlashLoanPool, which forwards the principal to the borrower callback with a 900k gas budget.
  gas: 60000 | value: 900000000000000000000 wei | tx: 0x0

Step 2 — Borrowed capital posted as an oracle bond
Inside the callback the attacker pushes the 900 ETH into SpotOracle. totalBond becomes 900 ETH and price() returns 9 ETH per base unit. 100 ETH of collateral is then valued at 900 ETH, so the 50% LTV cap is 450 ETH.
  gas: 180000 | value: 900000000000000000000 wei | tx: 0x0

Step 3 — Borrow, unwind the bond, repay the loan
The attacker borrows 450 ETH from CollateralVault, immediately unwinds the 900 ETH bond (no unbonding delay) and repays 900.9 ETH to the pool. The inflated price never had to persist, and the debt stays in the vault.
  gas: 240000 | value: 450000000000000000000 wei | tx: 0x0

## 3. State mutations (storage diff)

FlashLoanPool pool.liquidity (0x0000000000000000000000000000000000000000000000000000000000000000) [state]
  before: 0x00000000000000000000000000000000000000000000003635c9adc5dea00000
  after:  0x00000000000000000000000000000000000000000000003642471f01287a0000

SpotOracle oracle.bonds[attacker] (0x2690e5e24a20d3307ee7e2752efcc06c35d30389fa4ef7029e2d0eb72c621307) [state]
  before: 0x0000000000000000000000000000000000000000000000000000000000000000
  after:  0x0000000000000000000000000000000000000000000000000000000000000000

SpotOracle oracle.totalBond (0x0000000000000000000000000000000000000000000000000000000000000001) [oracle.price]
  before: 0x0000000000000000000000000000000000000000000000000000000000000000
  after:  0x000000000000000000000000000000000000000000000030ca024f987b900000

CollateralVault collateral[attacker] (0x2690e5e24a20d3307ee7e2752efcc06c35d30389fa4ef7029e2d0eb72c621307) [collateral]
  before: 0x0000000000000000000000000000000000000000000000000000000000000000
  after:  0x0000000000000000000000000000000000000000000000056bc75e2d63100000

CollateralVault debt[attacker] (0x39a31549d1a16a7ac9a70b2d36706d5fbb2a682e80a836983bae5866708f3327) [debt]
  before: 0x0000000000000000000000000000000000000000000000000000000000000000
  after:  0x000000000000000000000000000000000000000000000018650127cc3dc80000

## 4. Balance movements

CollateralVault 0x000000000000000000000000f62849f9a0b5bf2913b396098f7c7019b51a820a
  before: 1000000000000000000000 wei
  after:  650000000000000000000 wei
  delta:  -350000000000000000000 wei

FlashLoanPool 0x0000000000000000000000002e234dae75c793f67a35089c9d99245e1c58470b
  before: 1000000000000000000000 wei
  after:  1000900000000000000000 wei
  delta:  900000000000000000 wei

FlashLoanAttacker 0x000000000000000000000000a0cb889707d426a7a386870a03bc70d1b0697598
  before: 100000000000000000000 wei
  after:  449100000000000000000 wei
  delta:  349100000000000000000 wei

Victim EOA 0x0000000000000000000000007fa9385be102ac3eac297483dd6233d62b3e1496
  before: 0 wei
  after:  0 wei
  delta:  0 wei

## 5. Pattern findings

1. Oracle Manipulation — confidence 90%, severity critical
   Collateral valuation depends on a spot price the attacker can move within the same transaction, so the borrow limit is attacker-controlled.
   Evidence:
     - Oracle or price-source dependency identified (oracle, spot price)
     - Price-bearing storage slot mutated during the exploit: oracle.bonds[attacker] (0x2690e5e24a20d3307ee7e2752efcc06c35d30389fa4ef7029e2d0eb72c621307)
     - Attack sequence explicitly manipulates a quoted price before the extraction step

2. Flash Loan — confidence 85%, severity critical
   A flash-borrowed balance is used inside the same transaction to inflate a value assumption, so the attack is capital-free and atomic.
   Evidence:
     - Trace and artifact reference an atomic flash-borrow primitive (flashloan, flash loan, flashloanpool)
     - Attack step 1: Flash loan of 900 ETH

3. Reentrancy — confidence 79%, severity critical
   The same contract entry point is re-entered before its state update completes, letting the attacker pull funds across nested calls.
   Evidence:
     - Trace shows FlashLoanAttacker::receive invoked 3 times within a single transaction
     - Trace shows CollateralVault::debt invoked 2 times within a single transaction
     - 8 value-bearing calls observed in the exploit transaction

## 6. Root cause and remediation

SpotOracle derives its price from a bond that the depositor can unwind instantly, so a flash loan buys a 9x price move inside one transaction. CollateralVault lends against that spot price, leaving 450 ETH of debt backed by 100 ETH of collateral.

Recommended remediation: Review the affected contract paths and add invariant tests.

## 7. Evidence index

Artifact: artifacts/flash-loan.json
Trace: stored with the case, 216 lines
Gas flame nodes: 107
Pattern detections: 3
Reporter: HELIX forensic engine (Foundry simulation)

---

_Generated by HELIX — Web3 Exploit Forensics._