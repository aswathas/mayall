# delegatecall — Forensic Report

**Case reference:** lab-delegatecall  
**Generated:** 2026-10-30T20:30:04.328Z  
**Chain:** Ethereum  
**Severity:** CRITICAL  
**Confidence:** 93%  
**Evidence items:** 9

## Executive summary

A local Foundry reproduction of a delegate call injection attack drained 50 ETH from the target contract in a single transaction.

Root cause: execute() delegatecalls into a caller-supplied implementation with no allowlist. A contract that mirrors the vault's storage layout can read the vault's ETH and rewrite the vault's balances mapping, giving the attacker the entire balance.

The trace was classified as Delegate Call Injection with 93% confidence based on 13 piece(s) of evidence.

Secondary signals: Reentrancy.

This summary was produced from the simulated execution evidence; the same slot can be filled with a MiniMax Code authored narrative.

## 1. Scope

Case reference: lab-delegatecall
Scenario executed: delegatecall
Attack vector under investigation: Delegate Call Injection
Chain: Ethereum
Target contract: DelegateVault (0x5615dEB798BB3E4dFa0139dFa1b3D433Cc23b72f)
Execution: C:\Users\aswat\Projects\w3-forensics\.tools\foundry\forge.exe test --match-path test/DelegatecallExploit.t.sol --match-test testExploit -vvvv
Executed at: 2026-10-30T20:30:03.862Z (205 ms)

## 2. Attack sequence

Step 1 — Victim funds the vault
The victim deposits 50 ETH; the vault credits balances[victim] and holds the ETH.
  gas: 45000 | value: 50000000000000000000 wei | tx: 0x0

Step 2 — Attacker supplies a malicious implementation
execute() delegatecalls into any address the caller names. Nothing checks the implementation against an allowlist or verifies that the vault owner approved it.
  gas: 30000 | value: 0 wei | tx: 0x0

Step 3 — drain() executes in the vault's context
Under delegatecall address(this) is the vault, so drain() reads the vault's 50 ETH balance, writes balances[attacker] in the vault's storage and force-sends the funds to the attacker.
  gas: 62000 | value: 0 wei | tx: 0x0

## 3. State mutations (storage diff)

DelegateVault balances[attacker] (0x45776b2925604dc42346d8336574c3a2c6244d03c463c6964df61d84d520f9eb) [balance]
  before: 0x0000000000000000000000000000000000000000000000000000000000000000
  after:  0x000000000000000000000000000000000000000000000002b5e3af16b1880000

## 4. Balance movements

DelegateVault 0x0000000000000000000000005615deb798bb3e4dfa0139dfa1b3d433cc23b72f
  before: 50000000000000000000 wei
  after:  0 wei
  delta:  -50000000000000000000 wei

Attacker EOA 0x0000000000000000000000004269d4c5f33cbfe5d6718646e3a5da31fa616c6f
  before: 0 wei
  after:  50000000000000000000 wei
  delta:  50000000000000000000 wei

Victim EOA 0x0000000000000000000000007fa9385be102ac3eac297483dd6233d62b3e1496
  before: 950000000000000000000 wei
  after:  950000000000000000000 wei
  delta:  0 wei

## 5. Pattern findings

1. Delegate Call Injection — confidence 93%, severity critical
   The host contract delegates execution to an attacker-supplied implementation, which mutates the host's storage in the host's context.
   Evidence:
     - delegatecall observed in the execution trace (delegatecall)
     - Delegatecall frame: [1644206] DelegatecallExploitTest::testExploit()
     - Delegatecall frame: ├─ [0] VM::label(delegatecallAttacker: [0x4269D4C5F33CBfe5d6718646e3a5da31fa616c6f], "delegatecallAttacker")
     - Delegatecall frame: ├─ [0] VM::deal(DelegatecallExploitTest: [0x7FA9385bE102ac3EAc297483Dd6233D62b3e1496], 1000000000000000000000 [1e21])
     - Delegatecall frame: ├─ [0] VM::prank(delegatecallAttacker: [0x4269D4C5F33CBfe5d6718646e3a5da31fa616c6f])
     - Delegatecall frame: │   ├─ [29328] MaliciousImplementation::drain(delegatecallAttacker: [0x4269D4C5F33CBfe5d6718646e3a5da31fa616c6f]) [delegatecall]
     - Delegatecall frame: │   │   ├─ [0] delegatecallAttacker::receive{value: 50000000000000000000}()
     - Delegatecall frame: ├─ [2449] DelegateVault::balances(delegatecallAttacker: [0x4269D4C5F33CBfe5d6718646e3a5da31fa616c6f]) [staticcall]
     - Delegatecall frame: ├─ [0] VM::toString(DelegatecallExploitTest: [0x7FA9385bE102ac3EAc297483Dd6233D62b3e1496]) [staticcall]
     - Delegatecall frame: ├─ [0] VM::toString(delegatecallAttacker: [0x4269D4C5F33CBfe5d6718646e3a5da31fa616c6f]) [staticcall]
     - Delegatecall frame: ├─ [0] VM::toString(delegatecallAttacker: [0x4269D4C5F33CBfe5d6718646e3a5da31fa616c6f]) [staticcall]
     - Delegatecall frame: ├─ [0] VM::writeFile("C:\\Users\\aswat\\Projects\\w3-forensics\\artifacts/delegatecall.json", "{\"scenario\":\"delegatecall\",\"attackVector\":\"Unsafe Delegatecall\",\"chain\":\"Ethereum\",\"contractName\":\"DelegateVault\",\"target\":\"0x5615dEB798BB3E4dFa0139dFa1b3D433Cc23b72f\",\"attacker\":\"0x4269D4C5F33CBfe5d6718646e3a5da31fa616c6f\",\"exploited\":true,\"lossWei\":\"50000000000000000000\",\"lossEth\":\"50\",\"rootCause\":\"execute() delegatecalls into a caller-supplied implementation with no allowlist. A contract that mirrors the vault's storage layout can read the vault's ETH and rewrite the vault's balances mapping, giving the attacker the entire balance.\",\"severity\":\"critical\",\"steps\":[{\"n\":1,\"title\":\"Victim funds the vault\",\"description\":\"The victim deposits 50 ETH; the vault credits balances[victim] and holds the ETH.\",\"txHash\":\"0x0\",\"gasUsed\":45000,\"valueWei\":\"50000000000000000000\"},{\"n\":2,\"title\":\"Attacker supplies a malicious implementation\",\"description\":\"execute() delegatecalls into any address the caller names. Nothing checks the implementation against an allowlist or verifies that the vault owner approved it.\",\"txHash\":\"0x0\",\"gasUsed\":30000,\"valueWei\":\"0\"},{\"n\":3,\"title\":\"drain() executes in the vault's context\",\"description\":\"Under delegatecall address(this) is the vault, so drain() reads the vault's 50 ETH balance, writes balances[attacker] in the vault's storage and force-sends the funds to the attacker.\",\"txHash\":\"0x0\",\"gasUsed\":62000,\"valueWei\":\"0\"}],\"balances\":[{\"address\":\"0x0000000000000000000000005615deb798bb3e4dfa0139dfa1b3d433cc23b72f\",\"label\":\"DelegateVault\",\"beforeWei\":\"50000000000000000000\",\"afterWei\":\"0\",\"deltaWei\":\"-50000000000000000000\"},{\"address\":\"0x0000000000000000000000004269d4c5f33cbfe5d6718646e3a5da31fa616c6f\",\"label\":\"Attacker EOA\",\"beforeWei\":\"0\",\"afterWei\":\"50000000000000000000\",\"deltaWei\":\"50000000000000000000\"},{\"address\":\"0x0000000000000000000000007fa9385be102ac3eac297483dd6233d62b3e1496\",\"label\":\"Victim EOA\",\"beforeWei\":\"950000000000000000000\",\"afterWei\":\"950000000000000000000\",\"deltaWei\":\"0\"}],\"storageWrites\":[{\"contract\":\"0x5615dEB798BB3E4dFa0139dFa1b3D433Cc23b72f\",\"contractName\":\"DelegateVault\",\"slot\":\"0x45776b2925604dc42346d8336574c3a2c6244d03c463c6964df61d84d520f9eb\",\"label\":\"balances[attacker]\",\"before\":\"0x0000000000000000000000000000000000000000000000000000000000000000\",\"after\":\"0x000000000000000000000000000000000000000000000002b5e3af16b1880000\",\"kind\":\"balance\",\"changed\":true}],\"logs\":[{\"contract\":\"0x\",\"name\":\"Deposit\",\"args\":\"who=0x7FA9385bE102ac3EAc297483Dd6233D62b3e1496 amount=50000000000000000000\"},{\"contract\":\"0x\",\"name\":\"Drain\",\"args\":\"to=0x4269D4C5F33CBfe5d6718646e3a5da31fa616c6f amount=50000000000000000000\"}]}")
     - Attack sequence installs a caller-supplied implementation

2. Reentrancy — confidence 60%, severity critical
   The same contract entry point is re-entered before its state update completes, letting the attacker pull funds across nested calls.
   Evidence:
     - 2 value-bearing calls observed in the exploit transaction

## 6. Root cause and remediation

execute() delegatecalls into a caller-supplied implementation with no allowlist. A contract that mirrors the vault's storage layout can read the vault's ETH and rewrite the vault's balances mapping, giving the attacker the entire balance.

Recommended remediation: Review the affected contract paths and add invariant tests.

## 7. Evidence index

Artifact: artifacts/delegatecall.json
Trace: stored with the case, 124 lines
Gas flame nodes: 61
Pattern detections: 2
Reporter: HELIX forensic engine (Foundry simulation)

---

_Generated by HELIX — Web3 Exploit Forensics._